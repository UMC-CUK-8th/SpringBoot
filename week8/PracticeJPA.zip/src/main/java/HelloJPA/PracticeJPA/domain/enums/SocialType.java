package HelloJPA.PracticeJPA.domain.enums;

public enum SocialType {
    KAKAO, GOOGLE, NAVER, APPLE
}
