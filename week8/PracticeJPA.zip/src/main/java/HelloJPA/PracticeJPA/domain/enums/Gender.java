package HelloJPA.PracticeJPA.domain.enums;

public enum Gender {
    FEMALE, MALE, NONE
}
