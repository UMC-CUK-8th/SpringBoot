package HelloJPA.PracticeJPA.common.apiPayload.code;

public interface BaseCode {

    ReasonDto getReason();

    ReasonDto getReasonHttpStatus();
}