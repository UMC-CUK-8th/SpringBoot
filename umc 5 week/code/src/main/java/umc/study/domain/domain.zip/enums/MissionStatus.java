package umc.study.domain.enums;

public enum MissionStatus {
    CHALLENGING, COMPLETE
}
