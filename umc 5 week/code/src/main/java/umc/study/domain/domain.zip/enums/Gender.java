package umc.study.domain.enums;

public enum Gender {
    Male, Female
}
