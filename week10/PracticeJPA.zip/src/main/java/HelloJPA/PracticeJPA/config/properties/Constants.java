package HelloJPA.PracticeJPA.config.properties;

public class Constants {
    public static final String AUTH_HEADER = "Authorization";
    public static final String TOKEN_PREFIX = "Bearer ";
}
