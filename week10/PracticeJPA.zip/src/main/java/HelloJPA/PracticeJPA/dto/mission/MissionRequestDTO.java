package HelloJPA.PracticeJPA.dto.mission;

public class MissionRequestDTO {

}
