package HelloJPA.PracticeJPA.domain.enums;

public enum MemberStatus {
    ACTIVE, INACTIVE
}
