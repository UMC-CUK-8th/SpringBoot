package HelloJPA.PracticeJPA.domain.enums;

public enum MissionStatus {
    CHALLENGING, COMPLETED
}
