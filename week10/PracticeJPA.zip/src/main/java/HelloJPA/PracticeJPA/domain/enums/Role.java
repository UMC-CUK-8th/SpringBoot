package HelloJPA.PracticeJPA.domain.enums;

public enum Role {
    ADMIN,USER
}
